-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2019 at 07:21 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hrm_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(10) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `date` datetime(6) NOT NULL,
  `status` varchar(20) NOT NULL,
  `emp_in` time(6) NOT NULL,
  `emp_out` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `attendance_in_out`
--

CREATE TABLE `attendance_in_out` (
  `attend_in_out` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time_in` time(6) NOT NULL,
  `time_out` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department_info`
--

CREATE TABLE `department_info` (
  `dep_id` int(10) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `dep_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department_info`
--

INSERT INTO `department_info` (`dep_id`, `emp_id`, `dep_name`) VALUES
(1, 0, 'durpal'),
(2, 0, 'Roboot Science'),
(3, 0, 'Mobile Scince'),
(4, 0, 'Larval'),
(9, 0, 'Wordpress');

-- --------------------------------------------------------

--
-- Table structure for table `designation_info`
--

CREATE TABLE `designation_info` (
  `des_id` int(10) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `des_name` varchar(20) NOT NULL,
  `rank` varchar(20) NOT NULL,
  `basicsalary` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation_info`
--

INSERT INTO `designation_info` (`des_id`, `emp_id`, `des_name`, `rank`, `basicsalary`) VALUES
(4, 0, 'Games Developer', '', 0),
(10, 0, 'web', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `employee_info`
--

CREATE TABLE `employee_info` (
  `emp_id` int(10) NOT NULL,
  `dep_id` int(30) NOT NULL,
  `des_id` int(20) NOT NULL,
  `shift_id` int(20) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `emp_fname` varchar(100) NOT NULL,
  `emp_dob` date NOT NULL,
  `emp_cnic` varchar(100) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `emp_address` varchar(50) NOT NULL,
  `emp_image` text NOT NULL,
  `emp_contact` int(255) NOT NULL,
  `emp_email` varchar(50) NOT NULL,
  `emp_password` varchar(50) NOT NULL,
  `emp_role` varchar(50) NOT NULL,
  `emp_salary` int(30) NOT NULL,
  `join_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_info`
--

INSERT INTO `employee_info` (`emp_id`, `dep_id`, `des_id`, `shift_id`, `emp_name`, `emp_fname`, `emp_dob`, `emp_cnic`, `gender`, `emp_address`, `emp_image`, `emp_contact`, `emp_email`, `emp_password`, `emp_role`, `emp_salary`, `join_date`) VALUES
(30, 0, 0, 0, 'admin', '', '0000-00-00', '', '', '', '5d9e077c6a63dboss.png', 0, 'admin@gmail.com', 'admin123', 'admin', 0, '0000-00-00'),
(31, 0, 0, 0, 'user', '', '0000-00-00', '', '', '', '5d9e078c1e7092.png', 0, 'user@gmail.com', 'user123', 'user', 0, '0000-00-00'),
(33, 0, 0, 0, 'Boss', '', '0000-00-00', '', '', '', '5d9e1545aa4bcboss.png', 0, 'boss@gamil.com', 'boss123', 'admin', 0, '0000-00-00'),
(48, 1, 4, 1, 'Ali', 'Abudullah', '2019-10-15', '232-232323-22', 'male', 'peshawar', '5da5989e9ae75-.jpg_640x640.jpg', 2323233, 'ali@gmail.com', 'ali123', 'user', 120000, '2019-10-15');

-- --------------------------------------------------------

--
-- Table structure for table `notice_info`
--

CREATE TABLE `notice_info` (
  `notice_id` int(11) NOT NULL,
  `notice_title` varchar(255) NOT NULL,
  `notice_description` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE `payroll` (
  `pay_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `date_issue` date NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `department` varchar(30) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `total_salary` int(11) NOT NULL,
  `work_day` int(11) NOT NULL,
  `onedaysalary` int(11) NOT NULL,
  `absent_day` int(11) NOT NULL,
  `absent_salary` int(11) NOT NULL,
  `overtime` int(11) NOT NULL,
  `deduct` int(11) NOT NULL,
  `net_salary` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `shift_info`
--

CREATE TABLE `shift_info` (
  `shift_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `shift_name` varchar(20) NOT NULL,
  `shift_in` varchar(11) NOT NULL,
  `shift_out` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shift_info`
--

INSERT INTO `shift_info` (`shift_id`, `emp_id`, `shift_name`, `shift_in`, `shift_out`) VALUES
(1, 0, 'morning', '', ''),
(2, 0, 'evening', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `task_info`
--

CREATE TABLE `task_info` (
  `task_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `task_title` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `last_date` date NOT NULL,
  `detail` text NOT NULL,
  `rate` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`);

--
-- Indexes for table `attendance_in_out`
--
ALTER TABLE `attendance_in_out`
  ADD PRIMARY KEY (`attend_in_out`);

--
-- Indexes for table `department_info`
--
ALTER TABLE `department_info`
  ADD PRIMARY KEY (`dep_id`);

--
-- Indexes for table `designation_info`
--
ALTER TABLE `designation_info`
  ADD PRIMARY KEY (`des_id`);

--
-- Indexes for table `employee_info`
--
ALTER TABLE `employee_info`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `notice_info`
--
ALTER TABLE `notice_info`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `shift_info`
--
ALTER TABLE `shift_info`
  ADD PRIMARY KEY (`shift_id`);

--
-- Indexes for table `task_info`
--
ALTER TABLE `task_info`
  ADD PRIMARY KEY (`task_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance_in_out`
--
ALTER TABLE `attendance_in_out`
  MODIFY `attend_in_out` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department_info`
--
ALTER TABLE `department_info`
  MODIFY `dep_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `designation_info`
--
ALTER TABLE `designation_info`
  MODIFY `des_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `employee_info`
--
ALTER TABLE `employee_info`
  MODIFY `emp_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `notice_info`
--
ALTER TABLE `notice_info`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shift_info`
--
ALTER TABLE `shift_info`
  MODIFY `shift_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `task_info`
--
ALTER TABLE `task_info`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
